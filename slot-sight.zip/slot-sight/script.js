// ---------- Sample data (demo only, not a real AI) ----------
const lots = [
  { name: "Lot A - Main Entrance", capacity: 120, bias: 10 },
  { name: "Lot B - Basement", capacity: 200, bias: 0 },
  { name: "Lot C - Rooftop", capacity: 150, bias: -15 }
];

const timeBase = { morning: 70, midday: 85, afternoon: 75, evening: 55 };
const weatherBoost = { sunny: 0, rainy: 10 };
const eventBoost = {
  none: 0, rush: 10, sale: 20, match: 25,
  concert: 25, festival: 20, holiday: -10, conference: 15
};

function getStatus(percentFull) {
  if (percentFull >= 90) return "Almost full";
  if (percentFull >= 70) return "Filling up";
  return "Plenty of space";
}

// ---------- What happens when the button is clicked ----------
const button = document.getElementById("predict-btn");
const result = document.getElementById("result");

button.addEventListener("click", function () {
  const time = document.getElementById("time").value;
  const weather = document.getElementById("weather").value;
  const eventChoice = document.getElementById("event").value;

  let bestLot = null;
  let cards = "";

  lots.forEach(function (lot) {
    let percentFull = timeBase[time] + weatherBoost[weather] + eventBoost[eventChoice] + lot.bias;
    percentFull = Math.max(5, Math.min(100, percentFull));

    const freeSpaces = Math.round(lot.capacity * (100 - percentFull) / 100);

    if (bestLot === null || freeSpaces > bestLot.freeSpaces) {
      bestLot = { name: lot.name, freeSpaces: freeSpaces };
    }

    cards += '<div class="lot-card">' +
      "<h3>" + lot.name + "</h3>" +
      '<p class="lot-free">' + freeSpaces + " free spaces</p>" +
      '<p class="lot-status">' + getStatus(percentFull) + " (" + percentFull + "% full)</p>" +
      "</div>";
  });

  let headline = "Best choice: " + bestLot.name;
  if (bestLot.freeSpaces === 0) {
    headline = "All lots are likely to be full. Try a different time.";
  }

  result.innerHTML =
    '<p class="best">' + headline + "</p>" +
    '<div class="lot-grid">' + cards + "</div>" +
    '<p class="demo-note">Prediction for the next 30 to 60 minutes. Demo data: these numbers come from simple sample rules, not a real trained AI model.</p>';
});
// ---------- Pre-booking ----------
const bookButton = document.getElementById("book-btn");
const bookResult = document.getElementById("book-result");

// Today's date written as YYYY-MM-DD, the same format the date box uses
const now = new Date();
const todayText = now.getFullYear() + "-" +
  String(now.getMonth() + 1).padStart(2, "0") + "-" +
  String(now.getDate()).padStart(2, "0");

// Stops the date picker from offering past dates
document.getElementById("book-date").min = todayText;

// Makes typed text safe, so special characters are not treated as page code
function escapeText(text) {
  const box = document.createElement("div");
  box.textContent = text;
  return box.innerHTML;
}

function loadBookings() {
  try {
    return JSON.parse(localStorage.getItem("slotSightBookings")) || [];
  } catch (error) {
    return [];
  }
}

function saveBookings(list) {
  try {
    localStorage.setItem("slotSightBookings", JSON.stringify(list));
  } catch (error) {
    // If saving is blocked, the booking still shows for this visit
  }
}

function makeCode() {
  return "SS-" + Math.floor(1000 + Math.random() * 9000);
}

function showBookings(message) {
  const bookings = loadBookings();
  let cards = "";

  bookings.slice().reverse().forEach(function (b) {
    cards += '<div class="booking-card">' +
      "<h3>" + escapeText(b.code) + "</h3>" +
      "<p>" + escapeText(b.lot) + "</p>" +
      "<p>" + escapeText(b.date) + " at " + escapeText(b.time) + " (" + escapeText(b.duration) + ")</p>" +
      "<p>Vehicle: " + escapeText(b.vehicle) + "</p>" +
      "</div>";
  });

  let html = "";
  if (message) {
    html += '<p class="book-message">' + message + "</p>";
  }
  if (bookings.length > 0) {
    html += '<h3 class="book-heading">Your bookings</h3>' +
      '<div class="booking-list">' + cards + "</div>" +
      '<p class="demo-note">Demo only: bookings are saved in this browser, not on a server.</p>';
  }
  bookResult.innerHTML = html;
}

bookButton.addEventListener("click", function () {
  const lot = document.getElementById("book-lot").value;
  const date = document.getElementById("book-date").value;
  const time = document.getElementById("book-time").value;
  const duration = document.getElementById("book-duration").value;
  const vehicle = document.getElementById("book-vehicle").value.trim();

  if (date === "" || time === "" || vehicle === "") {
    bookResult.innerHTML = '<p class="book-error">Please fill in the date, arrival time and vehicle number.</p>';
    return;
  }

  if (date < todayText) {
    bookResult.innerHTML = '<p class="book-error">Please choose today or a future date.</p>';
    return;
  }

  const bookings = loadBookings();
  const code = makeCode();
  bookings.push({ code: code, lot: lot, date: date, time: time, duration: duration, vehicle: vehicle });
  saveBookings(bookings);

  showBookings("Slot reserved! Your booking code is " + code + ".");
});

// Show any bookings saved earlier when the page loads
showBookings("");